create
    definer = top_user@`%` procedure sum_and_del_ad()
BEGIN
#建表备份
DROP  TABLE IF EXISTS u_account_detail_copy;
CREATE TABLE u_account_detail_copy SELECT * FROM u_account_detail;
DROP  TABLE IF EXISTS u_account_detail_his_copy;
CREATE TABLE u_account_detail_his_copy SELECT * FROM u_account_detail_his;
DROP  TABLE IF EXISTS id_copy;
CREATE  TABLE id_copy
SELECT MIN(id) save_id, count(id) num,GROUP_CONCAT(id) p_id ,detail_type FROM (
SELECT * from u_account_detail_his
UNION
SELECT * from u_account_detail
) ad GROUP BY order_no,detail_type,user_id
HAVING num > 1;
#合并撤单金流
UPDATE u_account_detail ad SET amount = amount * (SELECT num from id_copy c where c.save_id = ad.id),
balance = balance + amount - (amount/(SELECT num from id_copy c where c.save_id = ad.id)),
remark = CONCAT('data_merge_by_',NOW())
WHERE  detail_type = 61 and (SELECT count(0) FROM id_copy c where c.save_id = id) > 0;

UPDATE u_account_detail_his ad SET amount = amount * (SELECT num from id_copy c where c.save_id = ad.id),
balance = balance + amount - (amount/(SELECT num from id_copy c where c.save_id = ad.id)),
remark = CONCAT('data_merge_by_',NOW())
WHERE  detail_type = 61 and (SELECT count(0) FROM id_copy c where c.save_id = id) > 0;
#删除重复
DELETE FROM u_account_detail WHERE (SELECT COUNT(0) FROM id_copy WHERE FIND_IN_SET(id,p_id) > 0 AND id != save_id) > 0;
DELETE FROM u_account_detail_his WHERE (SELECT COUNT(0) FROM id_copy WHERE FIND_IN_SET(id,p_id) > 0 AND id != save_id) > 0;
#加索引
ALTER TABLE u_account_detail add UNIQUE(order_no,detail_type,user_id);
ALTER TABLE u_account_detail_his add UNIQUE(order_no,detail_type,user_id);
DROP TABLE IF EXISTS id_copy;
END;

