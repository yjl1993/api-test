create
    definer = top_user@`%` procedure i()
begin
     declare i int default 1;
     while i < 1550 do
         insert into i_temp(i) values(i);
         set i = i + 1;
     end while;
end;

