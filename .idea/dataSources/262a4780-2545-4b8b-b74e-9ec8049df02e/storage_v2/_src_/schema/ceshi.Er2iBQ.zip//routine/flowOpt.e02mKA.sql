create
    definer = top_user@`%` procedure flowOpt(IN agentCode varchar(30), IN userId int, IN _offset int(9), IN _row int(7))
BEGIN
set @asql=concat('
CREATE TEMPORARY TABLE rechargeTmp
SELECT add_time tt , effect_betting_amount effect,dis_amount dis,amount recharge FROM u_user_recharge WHERE STATUS = 2 AND user_id = ',userId,'
UNION
SELECT add_time tt , effect_betting_amount effect,dis_amount dis,amount recharge FROM u_user_recharge_his WHERE STATUS = 2 AND user_id = ',userId,'
UNION
SELECT sys_time tt , effect_betting_amount effect,discount dis,amount recharge FROM s_bank_pay WHERE STATUS = 2 AND user_id = ',userId,'
UNION
SELECT trade_time tt, effect_betting_amount effect,discount dis,amount recharge FROM r_artificial_income WHERE user_id = ',userId);
prepare stml from @asql;
DROP TABLE IF EXISTS rechargeTmp;
EXECUTE stml;
set @asql=concat('
CREATE TEMPORARY TABLE bettingTmp
SELECT amount,add_time FROM u_user_betting where user_id = ',userId,' AND is_winning in (1,2)
UNION ALL
SELECT amount,add_time FROM u_user_betting_his where user_id = ',userId,' AND is_winning in (1,2)
UNION ALL
SELECT betting_amount amount,add_time FROM u_user_kyqp_betting where user_id = ',userId);
prepare stm2 from @asql;
DROP TABLE IF EXISTS bettingTmp;
EXECUTE stm2;
DROP TABLE IF EXISTS rechargeTmp1;
CREATE TEMPORARY TABLE rechargeTmp1 SELECT * FROM rechargeTmp;
DROP TABLE IF EXISTS tmp;
CREATE TEMPORARY TABLE tmp
SELECT compare.*, CAST(0 as decimal(10,2)) inval 			
FROM
(
		SELECT currentCheck.*,IFNULL(SUM(bettingTmp.amount),0) realBetting FROM 
		(
			SELECT a.*,DATE_FORMAT(IFNULL(b.endTime,NOW()),'%Y-%m-%d %H:%i:%s') endTime FROM
		(
			SELECT @rownum1:=@rownum1+1 AS rownum,
					 rechargeTmp.tt startTime,
					 rechargeTmp.effect effect,
					 rechargeTmp.dis dis,
					 rechargeTmp.recharge recharge
					FROM (SELECT @rownum1:=0) r,rechargeTmp
					ORDER BY startTime desc
		) a
		LEFT JOIN 
		(
			 SELECT @rownum2:=@rownum2+1 AS rownum,
							 rechargeTmp1.tt endTime
									FROM (SELECT @rownum2:=0) r, rechargeTmp1
									ORDER BY endTime desc
		) b
		ON a.rownum - 1  = b.rownum 
	) currentCheck
	LEFT JOIN bettingTmp ON bettingTmp.add_time BETWEEN currentCheck.startTime and currentCheck.endTime
	GROUP BY currentCheck.rownum
) compare;

DROP TABLE IF EXISTS tmp_copy;
CREATE TEMPORARY TABLE tmp_copy SELECT * FROM tmp;
DROP TABLE IF EXISTS tmp_copy1;
CREATE TEMPORARY TABLE tmp_copy1 SELECT * FROM tmp;
UPDATE tmp original SET inval = (
	CASE(
		(SELECT @inval:=(
					(
						SELECT SUM(copy.realBetting) FROM 
						tmp_copy copy where copy.rownum <= original.rownum
					)
					+
					(
						IFNULL((
								SELECT rui.lack FROM(
							SELECT @ddd:=LEAST((@ddd +copy.realBetting - copy.effect),0) lack ,copy.rownum
							FROM 
							(SELECT @ddd:=0) d,(SELECT * FROM tmp_copy1 ORDER BY rownum DESC) copy
							
							)rui WHERE rui.rownum > original.rownum ORDER BY rui.rownum ASC limit 1
						)
							
						,0)
						
						
					)
			)
			
	 ) > 0
 )WHEN TRUE THEN LEAST(@inval,original.effect) WHEN FALSE THEN 0 END
)WHERE rownum BETWEEN _offset +1 AND _offset + _row;
SELECT * from tmp LIMIT _offset ,_row;
DROP TEMPORARY TABLES tmp,tmp_copy,tmp_copy1,rechargeTmp,rechargeTmp1,bettingTmp;
END;

